# Comp 551 Kaggle Competition Instructions -

1. The preprocessed data already exists in the 'code/datasets' directory.
    It was generated using 'pre_processing.ipynb'.

2. Other notebooks included are 'TestingClassifiers.ipynb', 'neural_net.ipynb' and 'knn.ipynb'.
    The first one contains code for the baseline classifiers, the second one
    contains code for the neural network and the third one contains code for the k-nearest
    neighbours approach.

3. Install modules that may be missing on your system upon running of the notebooks.
